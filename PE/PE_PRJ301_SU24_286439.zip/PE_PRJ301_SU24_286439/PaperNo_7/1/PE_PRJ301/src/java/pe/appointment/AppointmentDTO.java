package pe.appointment;

public class AppointmentDTO {
    //your code here
    
}
